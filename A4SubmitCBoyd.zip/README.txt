install dependencies with
npm install

run the mongo daemon with 
mongod --dbpath=a4

initializes the database with
node database-initializer.js

run the server with 
node server.js

navigate to localhost:3000 to use the web application