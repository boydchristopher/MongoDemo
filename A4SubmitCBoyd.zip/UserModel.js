const mongoose = require("mongoose");
const Schema = mongoose.Schema;

//orders will be as JSON strings.
let userSchema = Schema({
  username: {type: String},
  password: {type: String},
  privacy: {type: Boolean},
  orders: [String]
});

module.exports = mongoose.model("User", userSchema);
