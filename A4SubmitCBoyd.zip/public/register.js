function init(){
  document.getElementById('submit').onclick = sumbitRegistration;
}

function submitRegistration(){
  let newUserName = document.getElementById('userName').value;
  let newPassword = document.getElementById('password').value;

  req = new XMLHttpRequest();
  req.onreadystatechange = function() {
		if(this.readyState==4 && this.status==200){
			alert("Logged In!");
		}
	}
}
