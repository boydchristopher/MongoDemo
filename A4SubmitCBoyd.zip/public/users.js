let queryField = document.getElementById('userName');
let submitButton = document.getElementById('submit');

function init(){
  submitButton.onclick = sendSearch;
}

function sendSearch(){
  window.location.href = "./users?query="+queryField.value;
}
