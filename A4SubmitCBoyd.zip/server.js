const express = require('express');
const session = require('express-session');
const mongoose = require('mongoose');
const MongoDBStore = require('connect-mongodb-session')(session);

const app = express();

let store = new MongoDBStore({
  uri: 'mongodb://localhost:27017/connect_mongodb_session_test',
  collection: 'mySessions'
});

//connect to users db
let Users = require('./UserModel');
mongoose.connect('mongodb://localhost/a4',{useNewUrlParser: true});
let db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));

//set session
app.use(session({secret: 'secure', store: store}));
app.use(function(req, res, next){
  //console.log(req.session);
  next();
});

//set pug
app.set('view engine','pug');

//serve static
app.use(express.static('public'));

//send pages
app.get('/',sendHomePage);
app.get('/users',sendUsersPage);
app.get('/users/:userID',sendUserPage);
app.get('/order',sendOrderPage);
app.get('/profile',sendProfilePage);
app.get('/registration',sendRegistrationPage);

//start server
db.once('open', function (){
  app.listen(3000);
});

console.log('Server listening at http://localhost:3000');

function sendHomePage(req,res,next){
  res.render('index',{session: req.session});
}

function sendUsersPage(req,res,next){
  console.log(req.query);
  if(req.query.query == null){
    res.render('users',{session: req.session});
  }
  else{
    Users.find()
    .where('username').regex(new RegExp(".*" + req.query.query + ".*", "i"))
    .where('privacy').eq('false')
    .exec(function(err, results){
      if(err){
        res.status(500).send('Error reading database');
        console.log(err);
        return;
      }
      res.render('userResults',{session: req.session, users: results});
    })
  }
}
function sendUserPage(req,res,next){
  console.log(req.params.userID);
  Users.findById(req.params.userID, function(err, result){
    if(err){
      console.log('error finding user');
      return;
    }
    if(!result.privacy){
      res.render('user',{session: req.session, user: result});
    }
  })
}

function sendOrderPage(req,res,next){
  res.render('order',{session: req.session});
}

function sendProfilePage(req,res,next){
  res.render('index',{session: req.session});
}

function sendRegistrationPage(req,res,next){
  res.render('register',{session: req.session});
}
